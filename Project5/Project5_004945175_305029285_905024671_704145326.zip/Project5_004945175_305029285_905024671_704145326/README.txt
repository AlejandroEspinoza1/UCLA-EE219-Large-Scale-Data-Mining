Project5_P1(1-3).ipynb is the code for problem 1.1, 1.2, 1.3.
Project5_p1-4_p1-5.ipynb is the code for problem 1.4 and 1.5, which should be run by Python 2.
Project5_P2.ipynb is the code for problem 2.
Project5_P3.ipynb is the code for problem 3.